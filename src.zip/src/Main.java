import user.AccountController;

public class Main {
    public static void main(String[] args) {
        AccountController account = new AccountController();
        account.run();
    }
}
